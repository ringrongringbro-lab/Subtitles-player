package com.asi.videoplayer

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.Locale

/**
 * SRT / VTT -> ASS converter (so libass draws everything the same way: fixed size relative to the
 * video, never moves when the video resolution changes), plus charset detection.
 * Real .ass / .ssa files are NOT converted, they keep all their own styles.
 */
object SubtitleTools {

    class Style(
        val size: Int = 52,
        val colorIdx: Int = 0,
        val outline: Int = 3,
        val bold: Boolean = false,
        val marginV: Int = 40
    )

    val colorNames = arrayOf("White", "Yellow", "Green", "Cyan", "Orange")
    private val colorAss = arrayOf("&H00FFFFFF", "&H0000FFFF", "&H0000FF00", "&H00FFFF00", "&H0000A5FF")

    fun decode(b: ByteArray): String {
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        var off = 0
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) off = 3
        val dec = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        return try {
            dec.decode(ByteBuffer.wrap(b, off, b.size - off)).toString()
        } catch (e: CharacterCodingException) {
            String(b, off, b.size - off, Charset.forName("windows-1252"))
        }
    }

    private fun header(st: Style, fontName: String): String = buildString {
        append("[Script Info]\nScriptType: v4.00+\nPlayResX: 1280\nPlayResY: 720\nWrapStyle: 0\nScaledBorderAndShadow: yes\n\n")
        append("[V4+ Styles]\n")
        append("Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n")
        append("Style: Default,").append(fontName).append(',')
            .append(st.size).append(',')
            .append(colorAss[st.colorIdx.coerceIn(0, colorAss.size - 1)]).append(',')
            .append("&H000000FF,&H00000000,&H80000000,")
            .append(if (st.bold) -1 else 0).append(",0,0,0,100,100,0,0,1,")
            .append(st.outline).append(",1,2,40,40,").append(st.marginV).append(",1\n\n")
        append("[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")
    }

    /** an ASS file with no lines = subtitle off */
    fun emptyAss(): String = header(Style(), "Roboto")

    private val TS = Regex("""(?:(\d+):)?(\d{1,2}):(\d{2})[.,](\d{1,3})""")

    private fun parseTs(s: String): Long? {
        val m = TS.find(s) ?: return null
        val h = m.groupValues[1].ifEmpty { "0" }.toLong()
        val mi = m.groupValues[2].toLong()
        val sec = m.groupValues[3].toLong()
        val ms = m.groupValues[4].padEnd(3, '0').toLong()
        return ((h * 60 + mi) * 60 + sec) * 1000 + ms
    }

    private fun assTime(ms: Long): String {
        val h = ms / 3_600_000
        val m = (ms / 60_000) % 60
        val s = (ms / 1000) % 60
        val cs = (ms % 1000) / 10
        return String.format(Locale.US, "%d:%02d:%02d.%02d", h, m, s, cs)
    }

    private fun rep(t: String, re: String, out: String): String =
        Regex(re, RegexOption.IGNORE_CASE).replace(t) { out }

    private fun clean(line: String): String {
        var t = line
        t = rep(t, "<\\s*i\\s*>", "{\\i1}")
        t = rep(t, "<\\s*/\\s*i\\s*>", "{\\i0}")
        t = rep(t, "<\\s*b\\s*>", "{\\b1}")
        t = rep(t, "<\\s*/\\s*b\\s*>", "{\\b0}")
        t = rep(t, "<\\s*u\\s*>", "{\\u1}")
        t = rep(t, "<\\s*/\\s*u\\s*>", "{\\u0}")
        t = Regex("<font[^>]*color\\s*=\\s*[\"']?#?([0-9a-fA-F]{6})[\"']?[^>]*>", RegexOption.IGNORE_CASE)
            .replace(t) { m ->
                val h = m.groupValues[1]
                "{\\c&H" + h.substring(4, 6) + h.substring(2, 4) + h.substring(0, 2) + "&}"
            }
        t = rep(t, "<\\s*/\\s*font\\s*>", "{\\r}")
        t = Regex("<[^>]+>").replace(t, "")
        // plain {text} (not an ASS tag) would be hidden by libass -> show it with brackets
        t = Regex("\\{(?!\\\\)([^}]*)\\}").replace(t) { m -> "(" + m.groupValues[1] + ")" }
        t = t.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&amp;", "&")
        return t
    }

    fun toAss(raw: String, st: Style, fontName: String): String {
        val sb = StringBuilder(header(st, fontName))
        val text = raw.replace("\r\n", "\n").replace('\r', '\n')
        val blocks = text.split(Regex("\n\\s*\n"))
        for (blk in blocks) {
            val lines = blk.split("\n")
            val ti = lines.indexOfFirst { it.contains("-->") }
            if (ti < 0) continue
            val parts = lines[ti].split("-->")
            if (parts.size < 2) continue
            val s = parseTs(parts[0]) ?: continue
            val e = parseTs(parts[1]) ?: continue
            if (e <= s) continue
            val body = lines.drop(ti + 1)
                .filter { it.isNotBlank() }
                .joinToString("\\N") { clean(it.trim()) }
            if (body.isBlank()) continue
            sb.append("Dialogue: 0,").append(assTime(s)).append(',').append(assTime(e))
                .append(",Default,,0,0,0,,").append(body).append('\n')
        }
        return sb.toString()
    }
}
