package com.asi.videoplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors

data class VideoItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val size: Long,
    val duration: Long,
    val added: Long,
    val height: Int,
    val folderKey: String,
    val folderName: String,
    val isSd: Boolean
)

data class FolderItem(
    val key: String,
    val name: String,
    val isSd: Boolean,
    val videos: List<VideoItem>
)

class MainActivity : Activity() {

    private val green = Color.parseColor("#2ECC71")
    private val grey = Color.parseColor("#AAAAAA")

    private var videos: List<VideoItem> = emptyList()
    private var tab = 0                    // 0 = Video, 1 = Folder
    private var currentFolder: String? = null
    private var currentStorage: Int? = null   // Folder tab: 0 = internal, 1 = SD card
    private var sortMode = 0               // 0 date, 1 name, 2 size, 3 length
    private var asc = false

    private lateinit var adapter: RowAdapter
    private lateinit var titleView: TextView
    private lateinit var tabVideo: TextView
    private lateinit var tabFolder: TextView

    private val thumbCache = LruCache<Long, Bitmap>(80)
    private val pool = Executors.newFixedThreadPool(3)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("asi", MODE_PRIVATE)
        sortMode = prefs.getInt("sortMode", 0)
        asc = prefs.getBoolean("asc", false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F0F0F"))
            setPadding(0, dp(36), 0, 0)
        }

        // Header: title (tap = back from folder), sort, open file
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(8), dp(8))
        }
        titleView = TextView(this).apply {
            text = "Asi Video Player"
            textSize = 20f
            setTextColor(Color.WHITE)
            setOnClickListener {
                if (currentFolder != null) {
                    currentFolder = null
                    render()
                } else if (currentStorage != null) {
                    currentStorage = null
                    render()
                }
            }
        }
        val sortBtn = TextView(this).apply {
            text = "⇅"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { showSort() }
        }
        val openBtn = TextView(this).apply {
            text = "📂 Open"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { pickFile() }
        }
        header.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(sortBtn)
        header.addView(openBtn)
        root.addView(header)

        // Tabs
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), 0, dp(8), dp(4))
        }
        tabVideo = TextView(this).apply {
            text = "Video"
            textSize = 17f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { tab = 0; currentFolder = null; currentStorage = null; render() }
        }
        tabFolder = TextView(this).apply {
            text = "Folder"
            textSize = 17f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { tab = 1; currentFolder = null; currentStorage = null; render() }
        }
        tabs.addView(tabVideo)
        tabs.addView(tabFolder)
        root.addView(tabs)

        // List
        val list = ListView(this).apply {
            divider = ColorDrawable(Color.parseColor("#1E1E1E"))
            dividerHeight = 1
        }
        adapter = RowAdapter()
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val r = adapter.rows[pos]
            if (r is VideoItem) {
                val vids = adapter.rows.filterIsInstance<VideoItem>()
                Playlist.set(vids.map { it.uri }, vids.indexOfFirst { it.id == r.id })
                play(r.uri)
            } else if (r is FolderItem) {
                if (r.key.startsWith("@storage|")) {
                    currentStorage = r.key.substringAfter('|').toInt()
                } else {
                    currentFolder = r.key
                }
                render()
            }
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        render()
        if (!hasPerm()) requestPermissions(arrayOf(perm()), 1)
    }

    override fun onResume() {
        super.onResume()
        if (hasPerm()) loadVideos()
    }

    private fun perm(): String =
        if (Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_VIDEO
        else android.Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPerm(): Boolean =
        checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadVideos()
        }
    }

    // ---------- loading (internal storage + SD card, via MediaStore) ----------

    @Suppress("DEPRECATION")
    private fun loadVideos() {
        pool.execute {
            val out = ArrayList<VideoItem>()
            try {
                val collection: Uri =
                    if (Build.VERSION.SDK_INT >= 29) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                    else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

                val proj = ArrayList<String>()
                proj.add(MediaStore.Video.Media._ID)
                proj.add(MediaStore.Video.Media.DISPLAY_NAME)
                proj.add(MediaStore.Video.Media.SIZE)
                proj.add(MediaStore.Video.Media.DURATION)
                proj.add(MediaStore.Video.Media.DATE_ADDED)
                proj.add(MediaStore.Video.Media.HEIGHT)
                if (Build.VERSION.SDK_INT >= 29) {
                    proj.add(MediaStore.Video.Media.RELATIVE_PATH)
                    proj.add(MediaStore.Video.Media.VOLUME_NAME)
                } else {
                    proj.add(MediaStore.Video.Media.DATA)
                }

                contentResolver.query(collection, proj.toTypedArray(), null, null, null)?.use { c ->
                    val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                    val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                    val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                    val iAdd = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                    val iH = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                    val iRel = if (Build.VERSION.SDK_INT >= 29) c.getColumnIndexOrThrow(MediaStore.Video.Media.RELATIVE_PATH) else -1
                    val iVol = if (Build.VERSION.SDK_INT >= 29) c.getColumnIndexOrThrow(MediaStore.Video.Media.VOLUME_NAME) else -1
                    val iData = if (Build.VERSION.SDK_INT < 29) c.getColumnIndexOrThrow(MediaStore.Video.Media.DATA) else -1

                    while (c.moveToNext()) {
                        val id = c.getLong(iId)
                        val key: String
                        val folderName: String
                        val isSd: Boolean
                        if (Build.VERSION.SDK_INT >= 29) {
                            val rel = c.getString(iRel) ?: ""
                            val vol = c.getString(iVol) ?: "external_primary"
                            isSd = vol != "external_primary"
                            key = "$vol|$rel"
                            val last = rel.trimEnd('/').substringAfterLast('/')
                            folderName = if (last.isNotEmpty()) last else if (isSd) "SD card" else "Internal storage"
                        } else {
                            val data = c.getString(iData) ?: ""
                            val parent = data.substringBeforeLast('/')
                            key = parent
                            folderName = parent.substringAfterLast('/')
                            isSd = !data.startsWith("/storage/emulated/")
                        }
                        out.add(
                            VideoItem(
                                id = id,
                                uri = ContentUris.withAppendedId(collection, id),
                                name = c.getString(iName) ?: "video",
                                size = c.getLong(iSize),
                                duration = c.getLong(iDur),
                                added = c.getLong(iAdd),
                                height = c.getInt(iH),
                                folderKey = key,
                                folderName = folderName,
                                isSd = isSd
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Videos load nahi hui", Toast.LENGTH_SHORT).show() }
            }
            runOnUiThread {
                videos = out
                render()
            }
        }
    }

    // ---------- sorting ----------

    private fun sortVideos(l: List<VideoItem>): List<VideoItem> {
        val cmp: Comparator<VideoItem> = when (sortMode) {
            1 -> compareBy<VideoItem> { it.name.lowercase(Locale.ROOT) }
            2 -> compareBy<VideoItem> { it.size }
            3 -> compareBy<VideoItem> { it.duration }
            else -> compareBy<VideoItem> { it.added }
        }
        return if (asc) l.sortedWith(cmp) else l.sortedWith(cmp.reversed())
    }

    private fun sortFolders(l: List<FolderItem>): List<FolderItem> {
        val cmp: Comparator<FolderItem> = when (sortMode) {
            1 -> compareBy<FolderItem> { it.name.lowercase(Locale.ROOT) }
            2 -> compareBy<FolderItem> { f -> f.videos.sumOf { v -> v.size } }
            3 -> compareBy<FolderItem> { f -> f.videos.sumOf { v -> v.duration } }
            else -> compareBy<FolderItem> { f -> f.videos.maxOf { v -> v.added } }
        }
        return if (asc) l.sortedWith(cmp) else l.sortedWith(cmp.reversed())
    }

    private fun showSort() {
        val modes = arrayOf("Date", "Name", "Size", "Length")
        val g1 = RadioGroup(this)
        for (i in modes.indices) {
            g1.addView(RadioButton(this).apply { text = modes[i]; id = 100 + i })
        }
        g1.check(100 + sortMode)
        val g2 = RadioGroup(this)
        g2.addView(RadioButton(this).apply { text = "From A to Z"; id = 200 })
        g2.addView(RadioButton(this).apply { text = "From Z to A"; id = 201 })
        g2.check(if (asc) 200 else 201)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        box.addView(g1)
        box.addView(g2)

        AlertDialog.Builder(this)
            .setTitle("Sort by")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                sortMode = g1.checkedRadioButtonId - 100
                asc = g2.checkedRadioButtonId == 200
                getSharedPreferences("asi", MODE_PRIVATE).edit()
                    .putInt("sortMode", sortMode).putBoolean("asc", asc).apply()
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- screen ----------

    private fun render() {
        val cf = currentFolder
        val rows: List<Any> = when {
            cf != null -> {
                val inFolder = videos.filter { it.folderKey == cf }
                titleView.text = "←  " + (inFolder.firstOrNull()?.folderName ?: "")
                sortVideos(inFolder)
            }
            tab == 0 -> {
                titleView.text = "Asi Video Player"
                sortVideos(videos)
            }
            else -> {
                titleView.text = "Asi Video Player"
                val cs = currentStorage
                if (cs == null) {
                    storageRows()
                } else {
                    titleView.text = "←  " + (if (cs == 1) "SD card" else "Internal storage")
                    val folders = videos.filter { it.isSd == (cs == 1) }.groupBy { it.folderKey }
                        .map { e -> FolderItem(e.key, e.value[0].folderName, e.value[0].isSd, e.value) }
                    sortFolders(folders)
                }
            }
        }
        tabVideo.setTextColor(if (tab == 0 && cf == null) green else Color.WHITE)
        tabFolder.setTextColor(if (tab == 1 || cf != null) green else Color.WHITE)
        adapter.rows = rows
        adapter.notifyDataSetChanged()
    }

    // Folder tab, first level: Internal storage / SD card
    private fun storageRows(): List<Any> {
        val out = ArrayList<FolderItem>()
        val internal = videos.filter { !it.isSd }
        val sd = videos.filter { it.isSd }
        if (internal.isNotEmpty()) out.add(FolderItem("@storage|0", "Internal storage", false, internal))
        if (sd.isNotEmpty()) out.add(FolderItem("@storage|1", "SD card", false, sd))
        return out
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (currentFolder != null) {
            currentFolder = null
            render()
        } else if (currentStorage != null && tab == 1) {
            currentStorage = null
            render()
        } else {
            super.onBackPressed()
        }
    }

    // ---------- list rows ----------

    private class VHolder(val thumb: ImageView, val title: TextView, val meta: TextView)
    private class FHolder(val title: TextView, val meta: TextView)

    private inner class RowAdapter : BaseAdapter() {
        var rows: List<Any> = emptyList()

        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getViewTypeCount(): Int = 2
        override fun getItemViewType(position: Int): Int = if (rows[position] is VideoItem) 0 else 1

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val r = rows[position]
            return if (r is VideoItem) videoRow(r, convertView) else folderRow(r as FolderItem, convertView)
        }
    }

    private fun videoRow(v: VideoItem, convertView: View?): View {
        val view: View
        val h: VHolder
        if (convertView == null) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            val thumb = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.parseColor("#222222"))
            }
            row.addView(thumb, LinearLayout.LayoutParams(dp(140), dp(80)))
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, 0, 0)
            }
            val title = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 15f
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            val meta = TextView(this).apply {
                setTextColor(grey)
                textSize = 13f
                setPadding(0, dp(4), 0, 0)
            }
            col.addView(title)
            col.addView(meta)
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            h = VHolder(thumb, title, meta)
            row.tag = h
            view = row
        } else {
            view = convertView
            h = convertView.tag as VHolder
        }
        h.title.text = v.name
        val res = if (v.height > 0) "${v.height}p | " else ""
        h.meta.text = res + fmtSize(v.size) + " | " + fmtDur(v.duration)
        loadThumb(v, h.thumb)
        return view
    }

    private fun folderRow(f: FolderItem, convertView: View?): View {
        val view: View
        val h: FHolder
        if (convertView == null) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(14), dp(12), dp(14))
            }
            val icon = TextView(this).apply {
                text = "📁"
                textSize = 32f
                setPadding(0, 0, dp(14), 0)
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val title = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 17f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val meta = TextView(this).apply {
                setTextColor(grey)
                textSize = 13f
            }
            col.addView(title)
            col.addView(meta)
            row.addView(icon)
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            h = FHolder(title, meta)
            row.tag = h
            view = row
        } else {
            view = convertView
            h = convertView.tag as FHolder
        }
        h.title.text = if (f.isSd) f.name + "  [SD]" else f.name
        h.meta.text = "${f.videos.size} videos"
        return view
    }

    @Suppress("DEPRECATION")
    private fun loadThumb(v: VideoItem, iv: ImageView) {
        iv.tag = v.id
        val cached = thumbCache.get(v.id)
        if (cached != null) {
            iv.setImageBitmap(cached)
            return
        }
        iv.setImageDrawable(null)
        pool.execute {
            val bmp: Bitmap? = try {
                if (Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(v.uri, Size(320, 180), null)
                } else {
                    MediaStore.Video.Thumbnails.getThumbnail(
                        contentResolver, v.id, MediaStore.Video.Thumbnails.MINI_KIND, null
                    )
                }
            } catch (e: Exception) {
                null
            }
            if (bmp != null) {
                thumbCache.put(v.id, bmp)
                runOnUiThread {
                    if (iv.tag == v.id) iv.setImageBitmap(bmp)
                }
            }
        }
    }

    private fun fmtSize(b: Long): String {
        val mb = b / (1024.0 * 1024.0)
        return if (mb >= 1024) String.format(Locale.US, "%.2fGB", mb / 1024.0)
        else String.format(Locale.US, "%.2fMB", mb)
    }

    private fun fmtDur(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    // ---------- open / play (unchanged behaviour) ----------

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, 2)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK) {
            data?.data?.let { Playlist.clear(); play(it) }
        }
    }

    private fun play(uri: Uri) {
        val i = Intent(this, PlayerActivity::class.java).apply {
            data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(i)
    }
}
