package com.asi.videoplayer

import android.graphics.Bitmap

/** JNI bridge to libass (see app/src/main/cpp/asi_jni.c). */
object AssNative {
    @Volatile
    private var loaded = false

    /** false = libass not available, the app then falls back to the basic ExoPlayer subtitle renderer */
    fun load(): Boolean {
        if (loaded) return true
        return try {
            System.loadLibrary("asijni")
            loaded = true
            true
        } catch (t: Throwable) {
            false
        }
    }

    @JvmStatic external fun nInit(fontsDir: String, defaultFont: String, family: String): Boolean
    @JvmStatic external fun nSetTrack(data: ByteArray): Boolean
    @JvmStatic external fun nSetSize(w: Int, h: Int, storageW: Int, storageH: Int)
    @JvmStatic external fun nRender(ts: Long, bitmap: Bitmap): Int
    @JvmStatic external fun nRelease()
    @JvmStatic external fun nSetDefaultFont(path: String)
}
