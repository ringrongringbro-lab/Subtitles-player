package com.asi.videoplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Handler
import android.os.HandlerThread
import android.view.Choreographer
import android.view.View
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Draws ASS subtitles with libass on top of the video. Every tag/style of the ASS file is
 * handled by libass itself. The subtitle text stays in memory only.
 */
class AssOverlay(
    context: Context,
    private val player: ExoPlayer,
    private val assData: ByteArray
) : View(context) {

    private val lock = Any()
    private var front: Bitmap? = null
    private var back: Bitmap? = null
    private var rectL = 0f
    private var rectT = 0f
    private var dispW = 0
    private var dispH = 0
    private var codedW = 0
    private var codedH = 0

    private val thread = HandlerThread("asi-ass").apply { start() }
    private val bg = Handler(thread.looper)
    private val busy = AtomicBoolean(false)

    @Volatile
    private var ready = false

    @Volatile
    private var running = true
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            tick()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val listener = object : Player.Listener {
        override fun onVideoSizeChanged(videoSize: VideoSize) {
            setVideo(videoSize)
        }
    }

    init {
        bg.post {
            val dir = "/system/fonts"
            val ok = AssNative.nInit(dir, pickDefaultFont(dir), "Roboto") && AssNative.nSetTrack(assData)
            ready = ok
        }
        player.addListener(listener)
        setVideo(player.videoSize)
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    private fun pickDefaultFont(dir: String): String {
        val all = File(dir).listFiles { f -> f.isFile && (f.name.endsWith(".ttf") || f.name.endsWith(".otf")) }
            ?: return ""
        val files = all.sortedBy { it.name }
        val pick = files.firstOrNull { it.name.startsWith("Roboto") && it.name.contains("Regular") }
            ?: files.firstOrNull { it.name.contains("NotoSans-Regular") }
            ?: files.firstOrNull { it.name.contains("Regular") }
            ?: files.firstOrNull()
        return pick?.absolutePath ?: ""
    }

    private fun setVideo(v: VideoSize) {
        if (v.width <= 0 || v.height <= 0) return
        codedW = v.width
        codedH = v.height
        val ratio = if (v.pixelWidthHeightRatio > 0f) v.pixelWidthHeightRatio else 1f
        dispW = (v.width * ratio).toInt().coerceAtLeast(1)
        dispH = v.height
        applySize()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applySize()
    }

    private fun applySize() {
        val vw = width
        val vh = height
        if (vw <= 0 || vh <= 0 || dispW <= 0 || dispH <= 0) return
        val s = minOf(vw.toFloat() / dispW, vh.toFloat() / dispH)
        val rw = (dispW * s).toInt().coerceAtLeast(2)
        val rh = (dispH * s).toInt().coerceAtLeast(2)
        rectL = (vw - rw) / 2f
        rectT = (vh - rh) / 2f
        val cw = codedW
        val ch = codedH
        bg.post {
            AssNative.nSetSize(rw, rh, cw, ch)
            val a = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888)
            val b = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888)
            synchronized(lock) {
                front = a
                back = b
            }
        }
    }

    private fun tick() {
        if (!ready || front == null) return
        if (!busy.compareAndSet(false, true)) return
        val ts = player.currentPosition
        bg.post {
            try {
                val b = synchronized(lock) { back }
                if (b != null && AssNative.nRender(ts, b) > 0) {
                    synchronized(lock) {
                        val t = front
                        front = back
                        back = t
                    }
                    postInvalidate()
                }
            } finally {
                busy.set(false)
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        synchronized(lock) {
            val b = front ?: return
            canvas.drawBitmap(b, rectL, rectT, paint)
        }
    }

    /** replace the subtitle track (used for external subtitle files, or an empty one = off) */
    fun setTrack(data: ByteArray) {
        bg.post { AssNative.nSetTrack(data) }
    }

    /** user font file */
    fun setFont(path: String) {
        bg.post { AssNative.nSetDefaultFont(path) }
    }

    fun release() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        player.removeListener(listener)
        bg.post {
            AssNative.nRelease()
            thread.quitSafely()
        }
    }
}
