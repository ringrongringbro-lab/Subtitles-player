package com.asi.videoplayer

import android.content.Context
import androidx.media3.exoplayer.ExoPlayer

// FFmpeg (more formats) will come back with the media3 / Play Store upgrade round
object PlayerFactory {
    fun create(ctx: Context): ExoPlayer = ExoPlayer.Builder(ctx).build()
}
