package com.asi.videoplayer

import android.app.Activity
import android.content.Intent
import android.media.AudioManager
import android.provider.Settings
import android.view.ViewConfiguration
import kotlin.math.abs
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Toast
import android.widget.TextView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var controls: FrameLayout
    private lateinit var seek: SeekBar
    private lateinit var timeNow: TextView
    private lateinit var timeTotal: TextView
    private lateinit var playBtn: TextView
    private lateinit var flashText: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var scale = 1f
    private var holding = false
    private var holdLeft = false
    private var wasPlaying = false
    private var userSeeking = false
    private var assOverlay: AssOverlay? = null

    // Side strips: left 22% and right 24% of the width. Middle = play/pause.
    private val leftEdge = 0.22f
    private val rightEdge = 0.76f

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    private val rewindTick = object : Runnable {
        override fun run() {
            if (holding && holdLeft) {
                player.seekTo((player.currentPosition - 1500).coerceAtLeast(0))
                handler.postDelayed(this, 150)
            }
        }
    }

    private val hideFlash = Runnable { flashText.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val uri: Uri? = intent.data
        if (uri == null) {
            finish()
            return
        }

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        // Video surface (TextureView so that zoom works properly)
        playerView = LayoutInflater.from(this).inflate(R.layout.player_surface, root, false) as PlayerView
        root.addView(playerView, FrameLayout.LayoutParams(match, match))

        // Invisible layer that catches all gestures
        val touchLayer = View(this)
        root.addView(touchLayer, FrameLayout.LayoutParams(match, match))

        // Small text feedback (+10 / 3x), no icons
        flashText = TextView(this).apply {
            textSize = 26f
            setTextColor(Color.WHITE)
            setShadowLayer(8f, 0f, 0f, Color.BLACK)
            visibility = View.GONE
        }
        root.addView(
            flashText,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )

        // Controls (hidden at start, single tap toggles)
        controls = FrameLayout(this)
        controls.visibility = View.GONE

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#99000000"))
            setPadding(24, 48, 24, 24)
        }
        val back = TextView(this).apply {
            text = "←"
            textSize = 28f
            setTextColor(Color.WHITE)
            setPadding(8, 0, 32, 0)
            setOnClickListener { finish() }
        }
        val title = TextView(this).apply {
            text = fileName(uri)
            textSize = 16f
            setTextColor(Color.WHITE)
            maxLines = 1
        }
        topBar.addView(back)
        topBar.addView(title)
        controls.addView(
            topBar,
            FrameLayout.LayoutParams(match, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        )

        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#99000000"))
            setPadding(24, 24, 24, 48)
        }
        playBtn = TextView(this).apply {
            text = "⏸"
            textSize = 28f
            setTextColor(Color.WHITE)
            setPadding(8, 0, 24, 0)
            setOnClickListener { togglePlay() }
        }
        timeNow = TextView(this).apply { text = "00:00"; setTextColor(Color.WHITE) }
        timeTotal = TextView(this).apply { text = "00:00"; setTextColor(Color.WHITE) }
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) timeNow.text = fmt(p.toLong())
            }
            override fun onStartTrackingTouch(s: SeekBar) { userSeeking = true }
            override fun onStopTrackingTouch(s: SeekBar) {
                player.seekTo(s.progress.toLong())
                userSeeking = false
            }
        })
        bottomBar.addView(playBtn)
        bottomBar.addView(timeNow)
        bottomBar.addView(seek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottomBar.addView(timeTotal)
        controls.addView(
            bottomBar,
            FrameLayout.LayoutParams(match, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )
        root.addView(controls, FrameLayout.LayoutParams(match, match))

        setContentView(root)
        hideSystemBars()

        // Player: any video (FFmpeg decoders via PlayerFactory)
        var assSub: ByteArray? = null
        player = PlayerFactory.create(this)
        player.setMediaItem(MediaItem.fromUri(uri))
        playerView.player = player

        // Subtitle look: no black box behind the text (Android's default caption style adds one),
        // keep the ASS file's own colour/size/bold/italic and draw a black outline only.
        playerView.subtitleView?.apply {
            setApplyEmbeddedStyles(true)
            setApplyEmbeddedFontSizes(true)
            setStyle(
                CaptionStyleCompat(
                    Color.WHITE,
                    Color.TRANSPARENT,
                    Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                    Color.BLACK,
                    null
                )
            )
        }
        val assBytes = assSub
        if (assBytes != null) {
            playerView.subtitleView?.visibility = View.GONE
            val ov = AssOverlay(this, player, assBytes)
            root.addView(ov, 1, FrameLayout.LayoutParams(match, match))
            assOverlay = ov
        }
        player.prepare()
        player.playWhenReady = true

        // Gestures
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                controls.visibility = if (controls.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                when (zone(e.x)) {
                    -1 -> { seekBy(-10_000); flash("◀◀ 10") }
                    1 -> { seekBy(10_000); flash("10 ▶▶") }
                    else -> togglePlay()
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                when (zone(e.x)) {
                    -1 -> startHold(true)
                    1 -> startHold(false)
                }
            }
        })

        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                scale = (scale * d.scaleFactor).coerceIn(1f, 4f)
                playerView.scaleX = scale
                playerView.scaleY = scale
                assOverlay?.scaleX = scale
                assOverlay?.scaleY = scale
                return true
            }
        })

        touchLayer.setOnTouchListener { _, ev ->
            sd.onTouchEvent(ev)
            if (!sd.isInProgress) gd.onTouchEvent(ev)
            swipeTouch(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                stopHold()
            }
            true
        }

        setupExtras(root)
        handler.post(ticker)
    }

    private fun zone(x: Float): Int {
        val r = x / playerView.width.toFloat()
        return if (r < leftEdge) -1 else if (r > rightEdge) 1 else 0
    }

    private fun seekBy(deltaMs: Long) {
        var t = player.currentPosition + deltaMs
        val d = player.duration
        if (d > 0) t = t.coerceAtMost(d)
        player.seekTo(t.coerceAtLeast(0))
    }

    private fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
        updateProgress()
    }

    private fun startHold(left: Boolean) {
        holding = true
        holdLeft = left
        wasPlaying = player.isPlaying
        if (left) {
            flash("◀◀")
            handler.post(rewindTick)
        } else {
            player.setPlaybackSpeed(3f)
            player.play()
            flashText.text = "3x ▶▶"
            flashText.visibility = View.VISIBLE
        }
    }

    private fun stopHold() {
        if (!holding) return
        holding = false
        player.setPlaybackSpeed(1f)
        if (!holdLeft && !wasPlaying) player.pause()
        handler.removeCallbacks(rewindTick)
        handler.removeCallbacks(hideFlash)
        handler.postDelayed(hideFlash, 300)
    }

    private fun flash(s: String) {
        flashText.text = s
        flashText.visibility = View.VISIBLE
        handler.removeCallbacks(hideFlash)
        handler.postDelayed(hideFlash, 600)
    }

    private fun updateProgress() {
        playBtn.text = if (player.isPlaying) "⏸" else "▶"
        if (userSeeking) return
        val dur = player.duration
        val pos = player.currentPosition
        if (dur > 0) {
            seek.max = dur.toInt()
            timeTotal.text = fmt(dur)
        }
        seek.progress = pos.toInt()
        timeNow.text = fmt(pos)
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }

    private fun fileName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: ""
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: ""
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    // ======================= NEW (added only; nothing above was changed) =======================
    // prev / next / shuffle / loop, auto-next in the same order as the list, swipe gestures

    private lateinit var btnPrev: TextView
    private lateinit var btnNext: TextView
    private lateinit var btnShuffle: TextView
    private lateinit var btnLoop: TextView
    private lateinit var audio: AudioManager
    private var switching = false
    private var tools: PlayerTools? = null

    private var swipeMode = 0   // 0 = undecided, 1 = seek, 2 = brightness, 3 = volume, -1 = ignore
    private var swDownX = 0f
    private var swDownY = 0f
    private var swStartPos = 0L
    private var swSeekTarget = 0L
    private var swStartBright = 0.5f
    private var swStartVol = 0f

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun setupExtras(root: FrameLayout) {
        audio = getSystemService(AUDIO_SERVICE) as AudioManager

        // opened from another app / file picker -> no list
        if (Playlist.current() != intent.data) Playlist.clear()

        if (Playlist.brightness >= 0f) setBrightness(Playlist.brightness)

        fun btn(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
            text = label
            textSize = 26f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { onClick() }
        }

        btnShuffle = btn("🔀") {
            Playlist.toggleShuffle()
            refreshPlaylistButtons()
            flash(if (Playlist.shuffle) "Shuffle ON" else "Shuffle OFF")
        }
        btnPrev = btn("⏮") { openPrev() }
        btnNext = btn("⏭") { openNext() }
        btnLoop = btn("🔁") {
            Playlist.cycleLoop()
            applyLoop()
            refreshPlaylistButtons()
            flash(when (Playlist.loop) { 1 -> "Loop all"; 2 -> "Loop one"; else -> "Loop OFF" })
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#66000000"))
        }
        row.addView(btnShuffle)
        row.addView(btnPrev)
        row.addView(btnNext)
        row.addView(btnLoop)
        controls.addView(
            row,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = dp(90) }
        )

        applyLoop()
        refreshPlaylistButtons()

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) onVideoEnded()
            }
        })

        // shortcut row: speed, music, subtitles, equalizer ... (see PlayerTools.kt)
        tools = PlayerTools(
            this, player, playerView, root, controls,
            { flash(it) },
            { assOverlay },
            { ov ->
                assOverlay = ov
                ov?.scaleX = scale
                ov?.scaleY = scale
            }
        )
    }

    private fun refreshPlaylistButtons() {
        btnPrev.alpha = if (Playlist.hasPrev()) 1f else 0.35f
        btnNext.alpha = if (Playlist.hasNext()) 1f else 0.35f
        btnShuffle.alpha = if (Playlist.shuffle) 1f else 0.45f
        btnLoop.text = if (Playlist.loop == 2) "🔂" else "🔁"
        btnLoop.alpha = if (Playlist.loop == 0) 0.45f else 1f
    }

    private fun applyLoop() {
        player.repeatMode = if (Playlist.loop == 2) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    private fun onVideoEnded() {
        val u = Playlist.next()
        if (u != null) {
            switchTo(u)
        } else if (Playlist.loop == 1) {
            player.seekTo(0)
            player.play()
        }
    }

    private fun openNext() {
        val u = Playlist.next()
        if (u == null) flash("Last video") else switchTo(u)
    }

    private fun openPrev() {
        val u = Playlist.prev()
        if (u == null) flash("First video") else switchTo(u)
    }

    @Suppress("DEPRECATION")
    private fun switchTo(u: Uri) {
        if (switching) return
        switching = true
        val i = Intent(this, PlayerActivity::class.java).apply {
            data = u
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(i)
        overridePendingTransition(0, 0)
        finish()
        overridePendingTransition(0, 0)
    }

    // ---- swipe gestures: left/right = seek, left side up/down = brightness, right side up/down = volume ----

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun setBrightness(v: Float) {
        val lp = window.attributes
        lp.screenBrightness = v
        window.attributes = lp
        Playlist.brightness = v
    }

    private fun swipeTouch(ev: MotionEvent) {
        val w = playerView.width.toFloat().coerceAtLeast(1f)
        val h = playerView.height.toFloat().coerceAtLeast(1f)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                swDownX = ev.x
                swDownY = ev.y
                swipeMode = 0
            }
            MotionEvent.ACTION_POINTER_DOWN -> swipeMode = -1
            MotionEvent.ACTION_MOVE -> {
                if (swipeMode == -1 || holding) return
                val dx = ev.x - swDownX
                val dy = ev.y - swDownY
                if (swipeMode == 0) {
                    val slop = ViewConfiguration.get(this).scaledTouchSlop * 2
                    if (abs(dx) < slop && abs(dy) < slop) return
                    if (abs(dx) > abs(dy)) {
                        swipeMode = 1
                        swStartPos = player.currentPosition
                        swSeekTarget = swStartPos
                    } else if (swDownX < w / 2f) {
                        swipeMode = 2
                        swStartBright = currentBrightness()
                    } else {
                        swipeMode = 3
                        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        swStartVol = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
                    }
                }
                when (swipeMode) {
                    1 -> {
                        var t = swStartPos + (dx / w * 120_000f).toLong()
                        t = t.coerceAtLeast(0)
                        val d = player.duration
                        if (d > 0) t = t.coerceAtMost(d)
                        swSeekTarget = t
                        val diff = (t - swStartPos) / 1000
                        flash((if (diff >= 0) "+" else "-") + abs(diff) + "s   " + fmt(t))
                    }
                    2 -> {
                        val v = (swStartBright - dy / h * 1.3f).coerceIn(0.02f, 1f)
                        setBrightness(v)
                        flash("☀ " + (v * 100).toInt() + "%")
                    }
                    3 -> {
                        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        val v = (swStartVol - dy / h * 1.3f).coerceIn(0f, 1f)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * max), 0)
                        flash("🔊 " + (v * 100).toInt() + "%")
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                if (swipeMode == 1) player.seekTo(swSeekTarget)
                swipeMode = 0
            }
            MotionEvent.ACTION_CANCEL -> swipeMode = 0
        }
    }

    override fun onPause() {
        super.onPause()
        if (::player.isInitialized && tools?.bgOn != true) player.pause()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        tools?.onResult(requestCode, resultCode, data)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tools?.release()
        assOverlay?.release()
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}
