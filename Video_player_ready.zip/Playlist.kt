package com.asi.videoplayer

import android.net.Uri

/**
 * Holds the list the user started a video from (in the exact order shown on screen,
 * so A-Z / size / date sorting is respected), plus shuffle / loop state.
 */
object Playlist {
    private var base: List<Uri> = emptyList()
    private var order: MutableList<Int> = mutableListOf()
    private var pos = 0

    var shuffle = false
        private set

    /** 0 = off, 1 = loop all, 2 = loop one */
    var loop = 0
        private set

    /** screen brightness chosen by swipe (-1 = system default) */
    var brightness = -1f

    fun set(list: List<Uri>, start: Int) {
        base = list
        rebuild(start.coerceIn(0, (list.size - 1).coerceAtLeast(0)))
    }

    fun clear() {
        base = emptyList()
        order = mutableListOf()
        pos = 0
    }

    private fun rebuild(current: Int) {
        order = base.indices.toMutableList()
        if (order.isEmpty()) {
            pos = 0
            return
        }
        if (shuffle) {
            order.shuffle()
            order.remove(current)
            order.add(0, current)
            pos = 0
        } else {
            pos = current
        }
    }

    fun current(): Uri? = if (order.isEmpty()) null else base[order[pos]]

    fun hasNext(): Boolean = order.isNotEmpty() && (pos < order.size - 1 || loop == 1)

    fun hasPrev(): Boolean = order.isNotEmpty() && (pos > 0 || loop == 1)

    fun next(): Uri? {
        if (order.isEmpty()) return null
        if (pos < order.size - 1) pos++ else if (loop == 1) pos = 0 else return null
        return base[order[pos]]
    }

    fun prev(): Uri? {
        if (order.isEmpty()) return null
        if (pos > 0) pos-- else if (loop == 1) pos = order.size - 1 else return null
        return base[order[pos]]
    }

    fun toggleShuffle() {
        val cur = if (order.isEmpty()) 0 else order[pos]
        shuffle = !shuffle
        rebuild(cur)
    }

    fun cycleLoop() {
        loop = (loop + 1) % 3
    }
}
