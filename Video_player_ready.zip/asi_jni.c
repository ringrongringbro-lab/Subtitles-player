// Thin JNI bridge: libass -> Android Bitmap (RGBA_8888, premultiplied)
#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#if __has_include(<ass/ass.h>)
#include <ass/ass.h>
#else
#include <ass.h>
#endif

#define TAG "AsiAss"

static ASS_Library *g_lib = NULL;
static ASS_Renderer *g_rend = NULL;
static ASS_Track *g_track = NULL;
static int g_force = 1;

static void msg_cb(int level, const char *fmt, va_list va, void *data) {
    (void)data;
    if (level > 6) return;
    __android_log_vprint(ANDROID_LOG_INFO, TAG, fmt, va);
}

static void free_all(void) {
    if (g_track) { ass_free_track(g_track); g_track = NULL; }
    if (g_rend) { ass_renderer_done(g_rend); g_rend = NULL; }
    if (g_lib) { ass_library_done(g_lib); g_lib = NULL; }
}

JNIEXPORT jboolean JNICALL
Java_com_asi_videoplayer_AssNative_nInit(JNIEnv *env, jclass cls, jstring fontsDir,
                                         jstring defaultFont, jstring family) {
    (void)cls;
    free_all();
    g_lib = ass_library_init();
    if (!g_lib) return JNI_FALSE;
    ass_set_message_cb(g_lib, msg_cb, NULL);
    ass_set_extract_fonts(g_lib, 1);

    const char *fd = fontsDir ? (*env)->GetStringUTFChars(env, fontsDir, NULL) : NULL;
    const char *df = defaultFont ? (*env)->GetStringUTFChars(env, defaultFont, NULL) : NULL;
    const char *fam = family ? (*env)->GetStringUTFChars(env, family, NULL) : NULL;

    if (fd && fd[0]) ass_set_fonts_dir(g_lib, fd);

    g_rend = ass_renderer_init(g_lib);
    if (g_rend) {
        ass_set_hinting(g_rend, ASS_HINTING_NONE);
        ass_set_fonts(g_rend, (df && df[0]) ? df : NULL, (fam && fam[0]) ? fam : "sans-serif",
                      ASS_FONTPROVIDER_AUTODETECT, NULL, 1);
    }

    if (fd) (*env)->ReleaseStringUTFChars(env, fontsDir, fd);
    if (df) (*env)->ReleaseStringUTFChars(env, defaultFont, df);
    if (fam) (*env)->ReleaseStringUTFChars(env, family, fam);

    return g_rend ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_asi_videoplayer_AssNative_nSetTrack(JNIEnv *env, jclass cls, jbyteArray arr) {
    (void)cls;
    if (!g_lib) return JNI_FALSE;
    if (g_track) { ass_free_track(g_track); g_track = NULL; }
    jsize len = (*env)->GetArrayLength(env, arr);
    char *buf = (char *)malloc((size_t)len + 1);
    if (!buf) return JNI_FALSE;
    (*env)->GetByteArrayRegion(env, arr, 0, len, (jbyte *)buf);
    buf[len] = 0;
    g_track = ass_read_memory(g_lib, buf, (size_t)len, NULL);
    free(buf);
    g_force = 1;
    return g_track ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_asi_videoplayer_AssNative_nSetSize(JNIEnv *env, jclass cls, jint w, jint h, jint sw, jint sh) {
    (void)env; (void)cls;
    if (!g_rend) return;
    ass_set_frame_size(g_rend, w, h);
    ass_set_storage_size(g_rend, sw > 0 ? sw : w, sh > 0 ? sh : h);
    g_force = 1;
}

// returns: -1 error, 0 nothing changed, 1 bitmap redrawn
JNIEXPORT jint JNICALL
Java_com_asi_videoplayer_AssNative_nRender(JNIEnv *env, jclass cls, jlong ts, jobject bitmap) {
    (void)cls;
    if (!g_rend || !g_track) return -1;

    int change = 0;
    ASS_Image *img = ass_render_frame(g_rend, g_track, (long long)ts, &change);
    if (change == 0 && !g_force) return 0;
    g_force = 0;

    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bitmap, &info) < 0) return -1;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) return -1;
    void *pixels = NULL;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0 || !pixels) return -1;

    for (uint32_t y = 0; y < info.height; y++) {
        memset((uint8_t *)pixels + (size_t)y * info.stride, 0, (size_t)info.width * 4);
    }

    for (; img; img = img->next) {
        uint32_t color = img->color;  // 0xRRGGBBAA, AA = transparency
        unsigned sr = (color >> 24) & 0xFF;
        unsigned sg = (color >> 16) & 0xFF;
        unsigned sb = (color >> 8) & 0xFF;
        unsigned ca = 255 - (color & 0xFF);
        if (ca == 0) continue;

        for (int y = 0; y < img->h; y++) {
            int dy = img->dst_y + y;
            if (dy < 0 || dy >= (int)info.height) continue;
            const uint8_t *src = img->bitmap + (size_t)y * img->stride;
            uint8_t *dst = (uint8_t *)pixels + (size_t)dy * info.stride;
            for (int x = 0; x < img->w; x++) {
                int dx = img->dst_x + x;
                if (dx < 0 || dx >= (int)info.width) continue;
                unsigned cov = src[x];
                if (!cov) continue;
                unsigned sa = (cov * ca + 127) / 255;
                if (!sa) continue;
                unsigned inv = 255 - sa;
                uint8_t *d = dst + (size_t)dx * 4;
                d[0] = (uint8_t)((sr * sa + d[0] * inv + 127) / 255);
                d[1] = (uint8_t)((sg * sa + d[1] * inv + 127) / 255);
                d[2] = (uint8_t)((sb * sa + d[2] * inv + 127) / 255);
                d[3] = (uint8_t)(sa + (d[3] * inv + 127) / 255);
            }
        }
    }

    AndroidBitmap_unlockPixels(env, bitmap);
    return 1;
}

JNIEXPORT void JNICALL
Java_com_asi_videoplayer_AssNative_nRelease(JNIEnv *env, jclass cls) {
    (void)env; (void)cls;
    free_all();
}

// user chosen subtitle font: becomes the default/fallback font of libass
JNIEXPORT void JNICALL
Java_com_asi_videoplayer_AssNative_nSetDefaultFont(JNIEnv *env, jclass cls, jstring path) {
    (void)cls;
    if (!g_rend || !path) return;
    const char *p = (*env)->GetStringUTFChars(env, path, NULL);
    if (p && p[0]) {
        ass_set_fonts(g_rend, p, "sans-serif", ASS_FONTPROVIDER_AUTODETECT, NULL, 1);
        g_force = 1;
    }
    if (p) (*env)->ReleaseStringUTFChars(env, path, p);
}
