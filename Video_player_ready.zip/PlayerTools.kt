package com.asi.videoplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.net.Uri
import android.view.Gravity
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.Locale

/**
 * All the extra player options in one place (shortcut row at the top of the controls):
 * equalizer, speed, screenshot, external music, rotation, subtitles (SRT/VTT/ASS + style + font),
 * audio/subtitle track, mute, A-B repeat, night mode, mirror, vertical flip, sleep timer,
 * background play, and "Customise items" (choose which buttons are visible).
 */
class PlayerTools(
    private val act: Activity,
    private val player: ExoPlayer,
    private val playerView: PlayerView,
    private val root: FrameLayout,
    private val controls: FrameLayout,
    private val flash: (String) -> Unit,
    private val getOverlay: () -> AssOverlay?,
    private val setOverlay: (AssOverlay?) -> Unit
) {

    companion object {
        const val REQ_SUB = 31
        const val REQ_FONT = 32
        const val REQ_MUSIC = 33
    }

    private class Item(val id: String, val label: String, val name: String)

    private val items = listOf(
        Item("eq", "🎚", "Equalizer"),
        Item("speed", "1x", "Playback Speed"),
        Item("shot", "📷", "Screenshot"),
        Item("music", "🎧", "Add Music"),
        Item("rotate", "⟳", "Screen Rotation"),
        Item("sub", "CC", "Subtitles"),
        Item("audio", "♪", "Audio Track"),
        Item("mute", "🔇", "Mute"),
        Item("ab", "A-B", "A - B Repeat"),
        Item("night", "🌙", "Night Mode"),
        Item("mirror", "↔", "Mirror Mode"),
        Item("flip", "↕", "Vertical Flip"),
        Item("sleep", "⏲", "Sleep Timer"),
        Item("bg", "BG", "Background Play")
    )

    private val prefs = act.getSharedPreferences("asi_tools", Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private val btns = HashMap<String, TextView>()
    private val bar = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(dp(8), dp(4), dp(8), dp(4))
    }
    private val night = View(act).apply {
        setBackgroundColor(Color.parseColor("#55FF8C00"))
        visibility = View.GONE
    }

    // speed
    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)
    private var userSpeed = 1f
    private var lastSpeed = 1f

    // audio
    private var originalOn = true
    private var music: ExoPlayer? = null
    private var eq: Equalizer? = null

    // A-B
    private var abStage = 0
    private var abA = 0L
    private var abB = 0L
    private val abTick = object : Runnable {
        override fun run() {
            if (abStage == 2) {
                if (player.currentPosition >= abB) player.seekTo(abA)
                handler.postDelayed(this, 150)
            }
        }
    }

    // picture
    private var mirror = false
    private var flip = false
    private var nightOn = false
    private var rotIdx = 0

    // sleep / background
    private var sleepRun: Runnable? = null
    var bgOn = false
        private set

    // subtitles
    private var subText = ""
    private var subKind: String? = null

    private fun dp(v: Int): Int = (v * act.resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    private fun fmtSpeed(f: Float): String =
        (if (f == f.toInt().toFloat()) f.toInt().toString() else f.toString()) + "x"

    private fun opt(label: String, f: () -> Unit): Pair<String, () -> Unit> = Pair(label, f)

    private fun menu(title: String, acts: List<Pair<String, () -> Unit>>) {
        AlertDialog.Builder(act)
            .setTitle(title)
            .setItems(acts.map { it.first }.toTypedArray()) { _, w -> acts[w].second() }
            .show()
    }

    private fun seekListener(onChange: (Int, Boolean) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { onChange(p, fromUser) }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    }

    // ------------------------------------------------------------------ shortcut bar

    private fun shown(): Set<String> {
        val s = prefs.getString("shown", null) ?: return items.map { it.id }.toSet()
        return s.split(",").filter { it.isNotEmpty() }.toSet()
    }

    private fun circle(label: String): TextView = TextView(act).apply {
        text = label
        textSize = 15f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#99000000"))
        }
    }

    private fun paint(id: String, on: Boolean) {
        val tv = btns[id] ?: return
        (tv.background as? GradientDrawable)?.setColor(Color.parseColor(if (on) "#CC2ECC71" else "#99000000"))
    }

    private fun rebuildBar() {
        bar.removeAllViews()
        btns.clear()
        val sh = shown()
        for (item in items) {
            if (item.id !in sh) continue
            val tv = circle(item.label)
            tv.setOnClickListener { onItem(item.id) }
            btns[item.id] = tv
            bar.addView(tv, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(8) })
        }
        val cust = circle("⚙")
        cust.setOnClickListener { customise() }
        bar.addView(cust, LinearLayout.LayoutParams(dp(46), dp(46)))
        refreshStates()
    }

    private fun refreshStates() {
        btns["speed"]?.text = fmtSpeed(userSpeed)
        paint("mute", !originalOn)
        paint("ab", abStage > 0)
        paint("night", nightOn)
        paint("mirror", mirror)
        paint("flip", flip)
        paint("sleep", sleepRun != null)
        paint("bg", bgOn)
        paint("music", music != null)
        paint("sub", subKind != null)
    }

    private fun customise() {
        val names = items.map { it.name }.toTypedArray()
        val sh = shown()
        val checked = BooleanArray(items.size) { items[it].id in sh }
        AlertDialog.Builder(act)
            .setTitle("Shortcuts")
            .setMultiChoiceItems(names, checked) { _, w, c -> checked[w] = c }
            .setPositiveButton("OK") { _, _ ->
                val ids = items.filterIndexed { i, _ -> checked[i] }.joinToString(",") { it.id }
                prefs.edit().putString("shown", ids).apply()
                rebuildBar()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onItem(id: String) {
        when (id) {
            "eq" -> showEq()
            "speed" -> showSpeed()
            "shot" -> screenshot()
            "music" -> showMusic()
            "rotate" -> rotate()
            "sub" -> showSub()
            "audio" -> pickTrack(C.TRACK_TYPE_AUDIO, "Audio track")
            "mute" -> toggleOriginal()
            "ab" -> abTap()
            "night" -> {
                nightOn = !nightOn
                night.visibility = if (nightOn) View.VISIBLE else View.GONE
                refreshStates()
            }
            "mirror" -> { mirror = !mirror; applyFlip(); refreshStates() }
            "flip" -> { flip = !flip; applyFlip(); refreshStates() }
            "sleep" -> showSleep()
            "bg" -> toggleBg()
        }
    }

    // ------------------------------------------------------------------ speed / mute / A-B

    private fun showSpeed() {
        val names = speeds.map { fmtSpeed(it) }.toTypedArray()
        AlertDialog.Builder(act)
            .setTitle("Playback speed")
            .setSingleChoiceItems(names, speeds.indexOf(userSpeed).coerceAtLeast(0)) { d, w ->
                userSpeed = speeds[w]
                player.setPlaybackSpeed(userSpeed)
                refreshStates()
                d.dismiss()
            }
            .show()
    }

    private fun toggleOriginal() {
        originalOn = !originalOn
        player.volume = if (originalOn) 1f else 0f
        flash(if (originalOn) "Original audio ON" else "Original audio OFF")
        refreshStates()
    }

    private fun abTap() {
        when (abStage) {
            0 -> {
                abA = player.currentPosition
                abStage = 1
                flash("A  " + fmt(abA))
            }
            1 -> {
                val p = player.currentPosition
                if (p <= abA + 500) {
                    flash("B, A se aage chuno")
                    return
                }
                abB = p
                abStage = 2
                flash("A-B loop ON")
                handler.post(abTick)
            }
            else -> {
                abStage = 0
                handler.removeCallbacks(abTick)
                flash("A-B OFF")
            }
        }
        refreshStates()
    }

    // ------------------------------------------------------------------ picture

    private fun applyFlip() {
        val tv = playerView.videoSurfaceView as? TextureView ?: return
        tv.scaleX = if (mirror) -1f else 1f
        tv.scaleY = if (flip) -1f else 1f
    }

    private fun rotate() {
        rotIdx = (rotIdx + 1) % 3
        when (rotIdx) {
            0 -> { act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; flash("Rotation: Auto") }
            1 -> { act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE; flash("Rotation: Landscape") }
            else -> { act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT; flash("Rotation: Portrait") }
        }
    }

    private fun screenshot() {
        val tv = playerView.videoSurfaceView as? TextureView
        val bmp: Bitmap? = tv?.bitmap
        if (bmp == null) {
            toast("Screenshot nahi bana")
            return
        }
        if (Build.VERSION.SDK_INT < 29) {
            toast("Screenshot ke liye Android 10+ chahiye")
            return
        }
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "Asi_" + System.currentTimeMillis() + ".png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AsiPlayer")
            }
            val u = act.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            if (u != null) {
                act.contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                flash("📷 Saved")
            }
        } catch (e: Exception) {
            toast("Screenshot save nahi hua")
        }
    }

    // ------------------------------------------------------------------ sleep timer / background play

    private fun showSleep() {
        val opts = arrayOf("Off", "15 min", "30 min", "45 min", "60 min", "90 min")
        val mins = intArrayOf(0, 15, 30, 45, 60, 90)
        AlertDialog.Builder(act)
            .setTitle("Sleep timer")
            .setItems(opts) { _, w ->
                sleepRun?.let { handler.removeCallbacks(it) }
                sleepRun = null
                if (mins[w] > 0) {
                    val r = Runnable {
                        player.pause()
                        sleepRun = null
                        flash("Sleep timer: paused")
                        refreshStates()
                    }
                    sleepRun = r
                    handler.postDelayed(r, mins[w] * 60_000L)
                    flash("Sleep: " + opts[w])
                } else {
                    flash("Sleep timer OFF")
                }
                refreshStates()
            }
            .show()
    }

    private fun toggleBg() {
        bgOn = !bgOn
        if (bgOn) {
            player.setWakeMode(C.WAKE_MODE_LOCAL)
            if (Build.VERSION.SDK_INT >= 33 &&
                act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 34)
            }
            try {
                val i = Intent(act, KeepAliveService::class.java)
                if (Build.VERSION.SDK_INT >= 26) act.startForegroundService(i) else act.startService(i)
            } catch (e: Exception) {
                toast("Background service start nahi hui")
            }
            flash("Background play ON")
        } else {
            player.setWakeMode(C.WAKE_MODE_NONE)
            act.stopService(Intent(act, KeepAliveService::class.java))
            flash("Background play OFF")
        }
        refreshStates()
    }

    // ------------------------------------------------------------------ equalizer

    private fun ensureEq(): Equalizer? {
        eq?.let { return it }
        val sid = player.audioSessionId
        if (sid == C.AUDIO_SESSION_ID_UNSET) return null
        return try {
            val e = Equalizer(0, sid)
            e.enabled = true
            prefs.getString("eq", null)?.split(",")?.forEachIndexed { i, s ->
                if (i < e.numberOfBands) s.toShortOrNull()?.let { e.setBandLevel(i.toShort(), it) }
            }
            eq = e
            e
        } catch (t: Throwable) {
            null
        }
    }

    private fun saveEq(e: Equalizer) {
        val n = e.numberOfBands.toInt()
        val csv = (0 until n).joinToString(",") { e.getBandLevel(it.toShort()).toString() }
        prefs.edit().putString("eq", csv).apply()
    }

    private fun showEq() {
        val e = ensureEq()
        if (e == null) {
            toast("Equalizer abhi available nahi, video chalne do")
            return
        }
        val n = e.numberOfBands.toInt()
        val lo = e.bandLevelRange[0].toInt()
        val hi = e.bandLevelRange[1].toInt()
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val seeks = ArrayList<SeekBar>()
        for (b in 0 until n) {
            val band = b.toShort()
            val hz = e.getCenterFreq(band) / 1000
            val lbl = TextView(act).apply {
                text = if (hz >= 1000) (hz / 1000).toString() + " kHz" else hz.toString() + " Hz"
            }
            val sb = SeekBar(act).apply {
                max = hi - lo
                progress = e.getBandLevel(band) - lo
                setOnSeekBarChangeListener(seekListener { p, fromUser ->
                    if (fromUser) {
                        e.setBandLevel(band, (p + lo).toShort())
                        saveEq(e)
                    }
                })
            }
            seeks.add(sb)
            box.addView(lbl)
            box.addView(sb)
        }
        AlertDialog.Builder(act)
            .setTitle("Equalizer")
            .setView(ScrollView(act).apply { addView(box) })
            .setPositiveButton("OK", null)
            .setNeutralButton("Reset") { _, _ ->
                for (b in 0 until n) e.setBandLevel(b.toShort(), 0)
                saveEq(e)
            }
            .show()
    }

    // ------------------------------------------------------------------ external music

    private fun pickFile(req: Int, mime: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
        }
        act.startActivityForResult(i, req)
    }

    private fun showMusic() {
        val acts = ArrayList<Pair<String, () -> Unit>>()
        acts.add(opt("Music chuno / badlo") { pickFile(REQ_MUSIC, "audio/*") })
        if (music != null) {
            acts.add(opt("Music hatao") {
                music?.release()
                music = null
                flash("Music removed")
                refreshStates()
            })
        }
        acts.add(opt(if (originalOn) "Original audio band karo" else "Original audio chalu karo") { toggleOriginal() })
        menu("Music", acts)
    }

    private fun startMusic(uri: Uri) {
        music?.release()
        val m = ExoPlayer.Builder(act).build()
        m.setMediaItem(MediaItem.fromUri(uri))
        m.repeatMode = Player.REPEAT_MODE_ALL
        m.prepare()
        m.setPlaybackSpeed(userSpeed)
        m.playWhenReady = player.isPlaying
        music = m
        flash("Music laga diya")
        refreshStates()
    }

    // ------------------------------------------------------------------ subtitles

    private fun loadStyle(): SubtitleTools.Style = SubtitleTools.Style(
        size = prefs.getInt("sub_size", 52),
        colorIdx = prefs.getInt("sub_color", 0),
        outline = prefs.getInt("sub_outline", 3),
        bold = prefs.getBoolean("sub_bold", false),
        marginV = prefs.getInt("sub_margin", 40)
    )

    private fun fontPath(): String? {
        val p = prefs.getString("font_path", null) ?: return null
        return if (File(p).exists()) p else null
    }

    private fun showSub() {
        val acts = ArrayList<Pair<String, () -> Unit>>()
        acts.add(opt("Subtitle file chuno (SRT / VTT / ASS)") { pickFile(REQ_SUB, "*/*") })
        acts.add(opt("Subtitle band karo") { subOff() })
        acts.add(opt("SRT / VTT style (size, color, outline)") { subStyleDialog() })
        acts.add(opt("Font file (ttf / otf)") { fontDialog() })
        acts.add(opt("Video ke andar wali subtitle / audio track") { pickTrack(C.TRACK_TYPE_TEXT, "Subtitle track") })
        menu("Subtitles", acts)
    }

    private fun subOff() {
        getOverlay()?.setTrack(SubtitleTools.emptyAss().toByteArray(Charsets.UTF_8))
        subKind = null
        subText = ""
        playerView.subtitleView?.visibility = View.VISIBLE
        flash("Subtitle OFF")
        refreshStates()
    }

    private fun applySubtitle() {
        val kind = subKind ?: return
        if (!AssNative.load()) {
            toast("Subtitle engine (libass) load nahi hua")
            return
        }
        val fp = fontPath()
        val ass = if (kind == "ass") subText
        else SubtitleTools.toAss(subText, loadStyle(), if (fp != null) "AsiUserFont" else "Roboto")
        val bytes = ass.toByteArray(Charsets.UTF_8)
        var ov = getOverlay()
        if (ov == null) {
            ov = AssOverlay(act, player, bytes)
            root.addView(ov, 1, FrameLayout.LayoutParams(match, match))
            setOverlay(ov)
            if (fp != null) ov.setFont(fp)
        } else {
            ov.visibility = View.VISIBLE
            ov.setTrack(bytes)
        }
        playerView.subtitleView?.visibility = View.GONE
        refreshStates()
    }

    private fun subStyleDialog() {
        val st = loadStyle()
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        fun slider(title: String, lo: Int, hi: Int, value: Int): SeekBar {
            val lbl = TextView(act).apply { text = title + ": " + value }
            val sb = SeekBar(act).apply {
                max = hi - lo
                progress = value - lo
                setOnSeekBarChangeListener(seekListener { p, _ -> lbl.text = title + ": " + (p + lo) })
            }
            box.addView(lbl)
            box.addView(sb)
            return sb
        }
        val sbSize = slider("Size", 20, 100, st.size)
        val sbOutline = slider("Outline", 0, 8, st.outline)
        val sbMargin = slider("Bottom gap", 0, 300, st.marginV)
        val bold = CheckBox(act).apply { text = "Bold"; isChecked = st.bold }
        box.addView(bold)
        val rg = RadioGroup(act)
        for (i in SubtitleTools.colorNames.indices) {
            rg.addView(RadioButton(act).apply { text = SubtitleTools.colorNames[i]; id = 500 + i })
        }
        rg.check(500 + st.colorIdx)
        box.addView(rg)
        box.addView(TextView(act).apply { text = "Ye sirf SRT / VTT par lagta hai. ASS file apne original style mein chalti hai." })

        AlertDialog.Builder(act)
            .setTitle("Subtitle style")
            .setView(ScrollView(act).apply { addView(box) })
            .setPositiveButton("Apply") { _, _ ->
                prefs.edit()
                    .putInt("sub_size", sbSize.progress + 20)
                    .putInt("sub_outline", sbOutline.progress)
                    .putInt("sub_margin", sbMargin.progress)
                    .putBoolean("sub_bold", bold.isChecked)
                    .putInt("sub_color", (rg.checkedRadioButtonId - 500).coerceAtLeast(0))
                    .apply()
                if (subKind != null && subKind != "ass") applySubtitle()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun fontDialog() {
        val acts = ArrayList<Pair<String, () -> Unit>>()
        acts.add(opt("Font file chuno") { pickFile(REQ_FONT, "*/*") })
        acts.add(opt("Default font wapas") {
            prefs.edit().remove("font_path").apply()
            toast("Agli video se default font")
        })
        menu("Subtitle font", acts)
    }

    private fun displayName(uri: Uri): String {
        try {
            act.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: ""
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: ""
    }

    /** called from PlayerActivity.onActivityResult; returns true if the request was ours */
    fun onResult(req: Int, res: Int, data: Intent?): Boolean {
        if (req != REQ_SUB && req != REQ_FONT && req != REQ_MUSIC) return false
        val uri = data?.data
        if (res != Activity.RESULT_OK || uri == null) return true
        when (req) {
            REQ_MUSIC -> startMusic(uri)
            REQ_SUB -> {
                val bytes = try {
                    act.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                } catch (e: Exception) {
                    null
                }
                if (bytes == null || bytes.isEmpty() || bytes.size > 20 * 1024 * 1024) {
                    toast("Subtitle file nahi padh paya")
                    return true
                }
                val text = SubtitleTools.decode(bytes)
                val lower = displayName(uri).lowercase(Locale.ROOT)
                subKind = when {
                    lower.endsWith(".ass") || lower.endsWith(".ssa") -> "ass"
                    lower.endsWith(".vtt") -> "vtt"
                    lower.endsWith(".srt") -> "srt"
                    text.contains("[Script Info]") -> "ass"
                    text.trimStart().startsWith("WEBVTT") -> "vtt"
                    else -> "srt"
                }
                subText = text
                applySubtitle()
                flash("Subtitle laga: " + subKind!!.uppercase(Locale.ROOT))
            }
            REQ_FONT -> {
                val bytes = try {
                    act.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                } catch (e: Exception) {
                    null
                }
                if (bytes == null || bytes.isEmpty() || bytes.size > 40 * 1024 * 1024) {
                    toast("Font file nahi padhi")
                    return true
                }
                val n = displayName(uri).lowercase(Locale.ROOT)
                val ext = if (n.endsWith(".otf")) "otf" else if (n.endsWith(".ttc")) "ttc" else "ttf"
                val f = File(act.filesDir, "user_font_" + System.currentTimeMillis() + "." + ext)
                try {
                    f.writeBytes(bytes)
                    prefs.getString("font_path", null)?.let { File(it).delete() }
                    prefs.edit().putString("font_path", f.absolutePath).apply()
                    getOverlay()?.setFont(f.absolutePath)
                    // SRT/VTT use a generated style name, rebuild so the font is picked up
                    if (subKind != null && subKind != "ass") applySubtitle()
                    toast("Font laga diya")
                } catch (e: Exception) {
                    toast("Font save nahi hua")
                }
            }
        }
        return true
    }

    // ------------------------------------------------------------------ audio / subtitle tracks inside the video

    private fun trackName(g: Tracks.Group, i: Int): String {
        val f = g.getTrackFormat(0)
        val parts = ArrayList<String>()
        f.label?.let { parts.add(it) }
        f.language?.let { if (it != "und") parts.add(it) }
        if (f.channelCount > 0 && f.sampleMimeType?.startsWith("audio") == true) parts.add(f.channelCount.toString() + "ch")
        return if (parts.isEmpty()) "Track " + (i + 1) else (i + 1).toString() + ". " + parts.joinToString(" · ")
    }

    private fun pickTrack(type: Int, title: String) {
        val groups = player.currentTracks.groups.filter { it.type == type && it.isSupported }
        if (groups.isEmpty()) {
            toast("Is video mein koi track nahi mila")
            return
        }
        val isText = type == C.TRACK_TYPE_TEXT
        val names = ArrayList<String>()
        if (isText) names.add("Off")
        groups.forEachIndexed { i, g -> names.add(trackName(g, i)) }
        val off = if (isText) 1 else 0
        AlertDialog.Builder(act)
            .setTitle(title)
            .setItems(names.toTypedArray()) { _, w ->
                val b = player.trackSelectionParameters.buildUpon()
                if (isText && w == 0) {
                    b.setTrackTypeDisabled(type, true)
                } else {
                    b.setTrackTypeDisabled(type, false)
                    b.setOverrideForType(TrackSelectionOverride(groups[w - off].mediaTrackGroup, 0))
                }
                player.trackSelectionParameters = b.build()
                if (isText && getOverlay() == null) playerView.subtitleView?.visibility = View.VISIBLE
            }
            .show()
    }

    // ------------------------------------------------------------------ lifecycle

    fun release() {
        handler.removeCallbacksAndMessages(null)
        music?.release()
        music = null
        try {
            eq?.release()
        } catch (t: Throwable) {
        }
        eq = null
        if (bgOn) {
            bgOn = false
            act.stopService(Intent(act, KeepAliveService::class.java))
        }
    }

    // keep this block last: it uses the properties declared above
    init {
        val sv = HorizontalScrollView(act).apply {
            isHorizontalScrollBarEnabled = false
            addView(bar)
        }
        controls.addView(
            sv,
            FrameLayout.LayoutParams(match, wrap, Gravity.TOP).apply { topMargin = dp(60) }
        )
        root.addView(night, 1, FrameLayout.LayoutParams(match, match))
        rebuildBar()

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                music?.playWhenReady = isPlaying
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (reason == Player.DISCONTINUITY_REASON_SEEK) {
                    music?.let {
                        val d = it.duration
                        it.seekTo(if (d > 0) newPosition.positionMs % d else newPosition.positionMs)
                    }
                }
            }

            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                // long-press 3x ends with speed 1x -> go back to the speed the user chose
                if (playbackParameters.speed == 1f && lastSpeed == 3f && userSpeed != 1f) {
                    player.setPlaybackSpeed(userSpeed)
                }
                lastSpeed = playbackParameters.speed
                music?.setPlaybackSpeed(playbackParameters.speed)
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                try {
                    eq?.release()
                } catch (t: Throwable) {
                }
                eq = null
                if (prefs.getString("eq", null) != null) ensureEq()
            }
        })
    }
}
